class Config(object):
    # 存储位置
    #SCHEDULER_JOBSTORES = {
    #    'default': SQLAlchemyJobStore(url='sqlite:///db/cese.db')
    #}
    # 线程池配置
    SCHEDULER_EXECUTORS = {
        'default': {'type': 'threadpool', 'max_workers': 10000}
    }
    SCHEDULER_JOB_DEFAULTS = {
        'coalesce': False,
        'max_instances': 10000
    }
    # 调度器控制
    SCHEDULER_API_PW = ''
    # 调度器开关
    SCHEDULER_API_ENABLED = True
    # 访问端口 --必填 只允许数字
    WEB_PORT = 9001
    #redis地址 --必填
    REDIS_ADDRESS = '127.0.0.1'
    #redis端口 --必填 只允许数字
    REDIS_PORT = 6379
    #redis数据库密码 --必填
    REDIS_PWD = 'qaz123qaz'
    #redis库索引 默认0-16
    REDIS_INDEX = 0
    # 数据库地址
    数据库地址 = '134.122.130.73'
    # 数据库端口
    数据库端口 = 3306
    # 数据库名称
    数据库名称 = 'jieqi'
    # 数据库用户
    数据库用户 = 'jieqi'
    # 数据库密码
    数据库密码 = ''
    # 数据库类型 gbk utf8 utf8mb4
    数据库编码 = ''
    # 数据库前缀
    数据库前缀 = ''
    # 后台账号
    后台账号 = 'admin'
    # 后台密码
    后台密码 = 'admin'