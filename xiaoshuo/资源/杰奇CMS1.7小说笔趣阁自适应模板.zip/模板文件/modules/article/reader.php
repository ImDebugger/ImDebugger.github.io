<?php 
//17mb.com
define('JIEQI_MODULE_NAME', 'article');
require_once('../../global.php');
if(empty($_REQUEST['aid'])) jieqi_printfail(LANG_ERROR_PARAMETER);
include_once(JIEQI_ROOT_PATH.'/header.php');
include_once($jieqiModules['article']['path'].'/class/package.php');
jieqi_includedb();$query=JieqiQueryHandler::getInstance('JieqiQueryHandler');
$package=new JieqiPackage($_REQUEST['aid']);
$aid = intval($_REQUEST['aid']);
$sid = intval($aid/1000);
if($package->loadOPF()){
    if(!empty($_REQUEST['aid']) && empty($_REQUEST['cid'])){
        $sql = "select * from jieqi_article_article where articleid = '$aid' ";
        $res=$query->execute($sql);
        $info = $query->getRow();
        $jieqiTpl->assign('17mb_fullflag',$info['fullflag']=='1'?'�걾':'����');
        $jieqiTpl->assign('17mb_uptime',$info['lastupdate']);
        $pathCover = "/files/article/image/$sid/$aid/{$aid}s.jpg";
        $fullPathCover = JIEQI_ROOT_PATH.$pathCover;
        $urlCover = JIEQI_URL.$pathCover;
        if(!is_file($fullPathCover)) $urlCover = "/modules/article/images/nocover.jpg";
        $jieqiTpl->assign('17mb_cover',$urlCover);
        $sql = "select chapterid,chaptername from jieqi_article_chapter where articleid = '$aid' and chaptertype = '0' order by chapterorder ";
        $res=$query->execute($sql);
        $numChapters = $query->db->getRowsNum($res);
        $firstid = 0;
        $arr = array();
        $i = 0;
        while($row=$query->getRow()){
            if($i==0) $firstid = $row['chapterid'];
            if($i>($numChapters-13)){
                $arr[$i]['chapterid'] = $row['chapterid'];
                $arr[$i]['chaptername'] = $row['chaptername'];
            }
            $i++;
        }
        $jieqiTpl->assign('17mb_firstid',$firstid);
        $arr = array_reverse($arr);
        $jieqiTpl->assign('17mb_chapters',$arr);
        $package->showIndex();
    }elseif(!empty($_REQUEST['aid']) && !empty($_REQUEST['cid'])){
        $cid = intval($_REQUEST['cid']);
        if(!$package->showChapter($cid)) $package->showIndex();
    }else{
        jieqi_printfail(LANG_ERROR_PARAMETER);
    }
}else{
	jieqi_loadlang('article', JIEQI_MODULE_NAME);
	jieqi_printfail($jieqiLang['article']['article_not_exists']);
}
?>