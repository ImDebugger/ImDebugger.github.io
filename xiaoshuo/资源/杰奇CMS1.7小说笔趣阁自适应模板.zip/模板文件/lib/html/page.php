<?php
//17mb.com
class JieqiPage extends JieqiObject
{
    var $total;
    var $onepage;
    var $num;
    var $page;
    var $total_page;
    var $linkhead;
    var $pagevar;
    var $usefake;
    var $useajax;
    var $ajax_parm = '{outid:\'content\', tipid:\'pagestats\', onLoading:\'loading...\', parameters:\'ajax_gets=jieqi_contents\'}';

    function JieqiPage($total, $onepage, $page = 1, $num = 10, $pagevar = 'page', $pageajax = 0){
        $this->total =& $total;
        $this->onepage =& $onepage;
        $this->total_page = @ceil($total/$onepage);
        if(defined('JIEQI_MAX_PAGES') && JIEQI_MAX_PAGES > 0 && $this->total_page > JIEQI_MAX_PAGES) $this->total_page = intval(JIEQI_MAX_PAGES);
		if($this->total_page <= 1) $this->total_page=1;
        $this->page =& $page;
        $this->num =& $num;
        $this->pagevar = $pagevar;
        
        if(substr($pagevar,0,1)=='.') $this->usefake=1;
        else $this->usefake=0;
        
        if($pageajax > 0 || (defined('JIEQI_AJAX_PAGE') && JIEQI_AJAX_PAGE > 0)) $this->useajax=1;
        else $this->useajax=0;
        
        $this->linkhead = jieqi_addurlvars(array($this->pagevar => ''), true, false);
    }

	function setlink($link='', $addget=true, $addpost=false){
		if(!empty($link)){
			$this->linkhead = $link;
		}else{
			$this->linkhead = jieqi_addurlvars(array($this->pagevar => ''), $addget, $addpost);
		}
	}
	
	function pageurl($page){
		if(strpos($this->linkhead, '<{$page') === false) $url = $this->linkhead.$page;
		else $url = str_replace(array('<{$page|subdirectory}>', '<{$page}>'), array(jieqi_getsubdir($page), $page), $this->linkhead);
		if($this->useajax == 1) $url = 'javascript:Ajax.Update(\''.urldecode($url).'\','.$this->ajax_parm.');';
		return $url;
	}
	
	function pagelink($page,$char,$class=''){
        $link_url = $this->pageurl($page);
        return '<li title="'.$char.'" ><a href="'.$link_url.'">'.$char.'</a></li>';
	}

    function pre_page($char=''){
        if ($char == '') $char = '&lt;';
        if ($this->page>1){
        	return $this->pagelink($this->page-1, $char, 'prev');
        }else{
            return '';
        }
    }

    function next_page($char=''){
        if ($char == '') $char = '&gt;';
        if ($this->page < $this->total_page){
        	return $this->pagelink($this->page+1, $char, 'next');
        }else{
            return '';
        }
    }

    function whole_num_bar(){
        return  '<li><span class="hd">�� <strong>'.$this->total.'</strong> ��С˵ ��ǰ��'.$this->page.'/'.$this->total_page.'</span></li>'.$this->pre_page('��һҳ') .$this->next_page('��һҳ');
    }
    
    function whole_bar(){
        return $this->whole_num_bar();
    }
}
?>