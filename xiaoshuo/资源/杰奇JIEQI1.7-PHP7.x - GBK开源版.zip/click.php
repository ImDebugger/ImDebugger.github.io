<?php
if($_GET['aid']){
	$aid = intval($_GET['aid']);
	$nowtime = date('U');
	require("configs/define.php");
	@mysql_connect(JIEQI_DB_HOST, JIEQI_DB_USER,JIEQI_DB_PASS)or die("1");  
	@mysql_select_db(JIEQI_DB_NAME)or die("2"); 
	$query = @mysql_query("update `jieqi_article_article` set `lastvisit` = '$nowtime',dayvisit = dayvisit+1,weekvisit = weekvisit+1,monthvisit = monthvisit+1,allvisit = allvisit+1 where `articleid` = '".$aid."' ") or die("3");
}
?>