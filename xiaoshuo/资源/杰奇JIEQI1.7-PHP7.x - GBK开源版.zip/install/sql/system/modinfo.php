<?php
$jieqiModinfo['system'] = array(
	'name'        => 'system',
	'caption'     => 'ϵͳ���',
	'description' => 'JIEQI CMSϵͳ���'
);
?>