<?php
class JieqiMySQLDatabase extends JieqiObject
{
	var $conn;
	var $lins;
	function JieqiMySQLDatabase($db=''){
		$this->JieqiObject();
	}
    function __construct($db=''){
        $this->JieqiObject();
    }
	function connect($dbhost='', $dbuser='', $dbpass='', $dbname='', $selectdb = true){
        $this->conn = @mysqli_connect($dbhost, $dbuser, $dbpass, $dbname);
		if (!$this->conn) return false;
		$this->links = array('dbhost' => $dbhost, 'dbuser'=>$dbuser, 'dbpass'=>$dbpass, 'dbname'=>$dbname, 'selectdb'=>$selectdb);
		//$this->connectcharset();
        $this->conn->query("SET NAMES gbk");
		return true;
	}
	function reconnect(){
		if(!mysqli_ping($this->conn)){
			$this->close();
			return $this->connect($this->links['dbhost'], $this->links['dbuser'], $this->links['dbpass'], $this->links['dbname'], $this->links['selectdb']);
		}else{
			$this->connectcharset();
			return true;
		}

	}
	function connectcharset(){
		$mysql_version = mysqli_get_server_info($this->conn);
		if($mysql_version > '4.1'){
			if(defined('JIEQI_DB_CHARSET')){
				if(JIEQI_DB_CHARSET != 'default') @mysqli_query("SET character_set_connection=".JIEQI_DB_CHARSET.", character_set_results=".JIEQI_DB_CHARSET.", character_set_client=binary", $this->conn);
			}else{
				@mysqli_query($this->conn,"SET character_set_connection=".JIEQI_SYSTEM_CHARSET.", character_set_results=".JIEQI_SYSTEM_CHARSET.", character_set_client=binary", $this->conn);
			}
		}
		if($mysql_version > '5.0'){
		    @mysqli_query("SET sql_mode=''", $this->conn);
        }
	}


	/**
	 * ȡ����һ��id
	 *
	 * @param      string      $sequence
	 * @access     public
	 * @return     int
	 */
	function genId($sequence=''){
		return 0;
	}

	/**
	 * ȡһ�У����������������飩
	 *
	 * @param      resource     $result
	 * @access     public
	 * @return     array        ����������������
	 */
	function fetchRow($result){
		return @mysqli_fetch_row($result);
	}

	/**
	 * ȡһ�У����������������飩
	 *
	 * @param      resource     $result
	 * @access     public
	 * @return     array        ����������������
	 */
	function fetchArray($result){
		return @mysqli_fetch_array($result,MYSQLI_ASSOC);
	}

	/**
	 * ȡ�����²���ID
	 *
	 * @param      void
	 * @access     public
	 * @return     int
	 */
	function getInsertId(){
		return mysqli_insert_id($this->conn);
	}

	/**
	 * ���ز�ѯ�������
	 *
	 * @param      void
	 * @access     public
	 * @return     int
	 */
	function getRowsNum($result){
		return @mysqli_num_rows($result);
	}

	/**
	 * ���ز�ѯӰ�������
	 *
	 * @param      void
	 * @access     public
	 * @return     int
	 */
	function getAffectedRows(){
		return mysqli_affected_rows($this->conn);
	}

	/**
	 * �ر�����
	 *
	 * @param      void
	 * @access     public
	 * @return     void
	 */
	function close(){
		@mysqli_close($this->conn);
		//if(defined('JIEQI_DEBUG_MODE') && JIEQI_DEBUG_MODE > 0) $this->sqllog('show');
	}

	/**
	 * �ͷŲ�ѯ���
	 *
	 * @param      void
	 * @access     public
	 * @return     void
	 */
	function freeRecordSet($result){
		return mysql_free_result($result);
	}

	/**
	 * ���ش�����Ϣ
	 *
	 * @param      void
	 * @access     public
	 * @return     string
	 */
	function error(){
		return @mysqli_error($this->conn);
	}

	/**
	 * ���ش������
	 *
	 * @param      void
	 * @access     public
	 * @return     int
	 */
	function errno(){
		return @mysqli_error($this->conn);
	}

	/**
	 * ��ѯ�ַ��������ַ��滻
	 *
	 * @param      string      $str
	 * @access     public
	 * @return     $str
	 */
	function quoteString($str){
		return "'".jieqi_dbslashes($str)."'";
	}

	function sqllog($do = 'add', $sql = ''){
		static $sqllog = array();
		switch($do){
			case 'add':
			if(!empty($sql)) $sqllog[] = $sql;
			break;
			case 'ret':
			return $sqllog;
			break;
			case 'count':
			return count($sqllog);
			break;
			case 'show':
			echo '<br />queries: '.count($sqllog);
			foreach($sqllog as $sql) echo '<br />'.jieqi_htmlstr($sql);
			break;
		}
	}

	/**
	 * ִ��һ����ѯ���
	 *
	 * @param      string      $sql ��ѯ��SQL
	 * @param      int         $limit ��������
	 * @param      int         $start ��ʼ����
	 * @param      bool        $nobuffer �Ƿ�����nobuffer��ѯ
	 * @access     public
	 * @return     bool
	 */
	function query($sql, $limit=0, $start=0, $nobuffer=false){

		if (!empty($limit)) {
			if(empty($start)) $start = 0;
			$sql.=' LIMIT '.(int)$start.', '.(int)$limit;
		}
		/*
		if(preg_match('/(char|outfile|load_file)/is', $sql)){
			$sqllog = "Time: ".date('Y-m-d H:i:s')."\r\nUrl: ";
			$sqllog .= !empty($_SERVER['REQUEST_URI']) ? $_SERVER['REQUEST_URI'] : $_SERVER['PHP_SELF'].'?'.$_SERVER['QUERY_STRING'];
			$sqllog .= "\r\nSql: ".$sql."\r\n\r\n";
			jieqi_checkdir(JIEQI_COMPILED_PATH.'/templates', true);
			jieqi_writefile(JIEQI_COMPILED_PATH.'/templates/sqllog.txt', $sqllog, 'ab');
		}
		*/
		if(defined('JIEQI_DEBUG_MODE') && JIEQI_DEBUG_MODE > 0) $this->sqllog('add', $sql);
		if($nobuffer) $result = mysqli_query($this->conn, $sql);##
		else $result = mysqli_query($this->conn,$sql);
		if ($result) return $result;
		else{
			//�������Ϊʱ�䳤�˶Ͽ����ӣ��Զ����������²�ѯ
			$errno = mysqli_errno($this->conn);
			if($errno == 2013 || $errno == 2006){
				$this->reconnect();
				if($nobuffer) $result = mysql_unbuffered_query($sql, $this->conn);
				else $result = mysqli_query($sql, $this->conn);
				if ($result) return $result;
			}
			if(defined('JIEQI_DEBUG_MODE') && JIEQI_DEBUG_MODE > 0){
				jieqi_printfail('SQL: '.jieqi_htmlstr($sql).'<br /><br />ERROR: '.mysqli_error($this->conn).'('.mysqli_errno($this->conn).')');
			}
			return false;
		}
	}
}
?>