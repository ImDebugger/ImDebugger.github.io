<?php
$jieqiRight['system']['maxfriends']['caption'] = '��������';
$jieqiRight['system']['maxfriends']['honors']['1'] = '';
$jieqiRight['system']['maxfriends']['honors']['2'] = '';
$jieqiRight['system']['maxfriends']['honors']['3'] = '';
$jieqiRight['system']['maxfriends']['honors']['4'] = '';
$jieqiRight['system']['maxfriends']['honors']['5'] = '';
$jieqiRight['system']['maxfriends']['honors']['6'] = '';
$jieqiRight['system']['maxfriends']['rescription'] = '';
$jieqiRight['system']['maxmessages']['caption'] = '���������Ϣ��';
$jieqiRight['system']['maxmessages']['honors']['1'] = '';
$jieqiRight['system']['maxmessages']['honors']['2'] = '';
$jieqiRight['system']['maxmessages']['honors']['3'] = '';
$jieqiRight['system']['maxmessages']['honors']['4'] = '';
$jieqiRight['system']['maxmessages']['honors']['5'] = '';
$jieqiRight['system']['maxmessages']['honors']['6'] = '';
$jieqiRight['system']['maxmessages']['rescription'] = '';
$jieqiRight['system']['maxdaymsg']['caption'] = 'ÿ����������Ϣ��';
$jieqiRight['system']['maxdaymsg']['honors']['1'] = '';
$jieqiRight['system']['maxdaymsg']['honors']['2'] = '';
$jieqiRight['system']['maxdaymsg']['honors']['3'] = '';
$jieqiRight['system']['maxdaymsg']['honors']['4'] = '';
$jieqiRight['system']['maxdaymsg']['honors']['5'] = '';
$jieqiRight['system']['maxdaymsg']['honors']['6'] = '';
$jieqiRight['system']['maxdaymsg']['rescription'] = '';

?>