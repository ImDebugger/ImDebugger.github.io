<?php
$jieqiModules['system'] = array('caption'=>'ϵͳ����', 'dir'=>'', 'path'=>'', 'url'=>'', 'theme'=>'', 'publish'=>'1');
$jieqiModules['article'] = array('caption'=>'С˵����', 'dir'=>'', 'path'=>'', 'url'=>'', 'theme'=>'', 'publish'=>'1');
$jieqiModules['forum'] = array('caption'=>'������̳', 'dir'=>'', 'path'=>'', 'url'=>'', 'theme'=>'', 'publish'=>'0');
$jieqiModules['obook'] = array('caption'=>'�������', 'dir'=>'', 'path'=>'', 'url'=>'', 'theme'=>'', 'publish'=>'0');
$jieqiModules['pay'] = array('caption'=>'���߳�ֵ', 'dir'=>'', 'path'=>'', 'url'=>'', 'theme'=>'', 'publish'=>'0');
$jieqiModules['cartoon'] = array('caption'=>'��������', 'dir'=>'', 'path'=>'', 'url'=>'', 'theme'=>'', 'publish'=>'0');
$jieqiModules['quiz'] = array('caption'=>'�����ʴ�', 'dir'=>'', 'path'=>'', 'url'=>'', 'theme'=>'', 'publish'=>'0');
$jieqiModules['info'] = array('caption'=>'������Ϣ', 'dir'=>'', 'path'=>'', 'url'=>'', 'theme'=>'', 'publish'=>'0');
$jieqiModules['link'] = array('caption'=>'��������', 'dir'=>'', 'path'=>'', 'url'=>'', 'theme'=>'', 'publish'=>'0');
$jieqiModules['vote'] = array('caption'=>'ͶƱ����', 'dir'=>'', 'path'=>'', 'url'=>'', 'theme'=>'', 'publish'=>'0');
$jieqiModules['note'] = array('caption'=>'��������', 'dir'=>'', 'path'=>'', 'url'=>'', 'theme'=>'', 'publish'=>'0');
$jieqiModules['news'] = array('caption'=>'���ŷ���', 'dir'=>'', 'path'=>'', 'url'=>'', 'theme'=>'', 'publish'=>'0');
$jieqiModules['group'] = array('caption'=>'Ȧ�ӽ���', 'dir'=>'', 'path'=>'', 'url'=>'', 'theme'=>'', 'publish'=>'0');
$jieqiModules['space'] = array('caption'=>'���˿ռ�', 'dir'=>'', 'path'=>'', 'url'=>'', 'theme'=>'', 'publish'=>'0');
$jieqiModules['badge'] = array('caption'=>'���²��', 'dir'=>'', 'path'=>'', 'url'=>'', 'theme'=>'', 'publish'=>'0');
$jieqiModules['wap'] = array('caption'=>'WAPϵͳ', 'dir'=>'/wap', 'path'=>'D:/work/demo/17mb/jieqi/17/09/wap', 'url'=>'http://17mb-jieqi17-09.a.com/wap', 'theme'=>'', 'publish'=>'0');
$jieqiModules['waparticle'] = array('caption'=>'WAPС˵', 'dir'=>'/wap/article', 'path'=>'D:/work/demo/17mb/jieqi/17/09/wap/article', 'url'=>'http://17mb-jieqi17-09.a.com/wap/article', 'theme'=>'', 'publish'=>'0');
$jieqiModules['wapforum'] = array('caption'=>'WAP��̳', 'dir'=>'/wap/forum', 'path'=>'D:/work/demo/17mb/jieqi/17/09/wap/forum', 'url'=>'http://17mb-jieqi17-09.a.com/wap/forum', 'theme'=>'', 'publish'=>'0');
?>