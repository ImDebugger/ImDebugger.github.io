<?php 
$jieqiSmiles[0] = array('code'=>'/:O', 'url'=>'1.gif', 'emotion'=>'����');
$jieqiSmiles[1] = array('code'=>'/:~', 'url'=>'2.gif', 'emotion'=>'Ʋ��');
$jieqiSmiles[2] = array('code'=>'/:*', 'url'=>'3.gif', 'emotion'=>'ɫɫ');
$jieqiSmiles[3] = array('code'=>'/:|', 'url'=>'4.gif', 'emotion'=>'����');
$jieqiSmiles[4] = array('code'=>'/8-)', 'url'=>'5.gif', 'emotion'=>'����');
$jieqiSmiles[5] = array('code'=>'/:LL', 'url'=>'6.gif', 'emotion'=>'����');
$jieqiSmiles[6] = array('code'=>'/:$', 'url'=>'7.gif', 'emotion'=>'����');
$jieqiSmiles[7] = array('code'=>'/:X', 'url'=>'8.gif', 'emotion'=>'����');
$jieqiSmiles[8] = array('code'=>'/:Z', 'url'=>'9.gif', 'emotion'=>'˯��');
$jieqiSmiles[9] = array('code'=>'/:`(', 'url'=>'10.gif', 'emotion'=>'���');
$jieqiSmiles[10] = array('code'=>'/:-', 'url'=>'11.gif', 'emotion'=>'����');
$jieqiSmiles[11] = array('code'=>'/:@', 'url'=>'12.gif', 'emotion'=>'��ŭ');
$jieqiSmiles[12] = array('code'=>'/:P', 'url'=>'13.gif', 'emotion'=>'��Ƥ');
$jieqiSmiles[13] = array('code'=>'/:D', 'url'=>'14.gif', 'emotion'=>'����');
$jieqiSmiles[14] = array('code'=>'/:)', 'url'=>'15.gif', 'emotion'=>'΢Ц');
$jieqiSmiles[15] = array('code'=>'/:(', 'url'=>'16.gif', 'emotion'=>'�ѹ�');
$jieqiSmiles[16] = array('code'=>'/:+', 'url'=>'17.gif', 'emotion'=>'ˣ��');
$jieqiSmiles[17] = array('code'=>'/:#', 'url'=>'18.gif', 'emotion'=>'����');
$jieqiSmiles[18] = array('code'=>'/:Q', 'url'=>'19.gif', 'emotion'=>'ץ��');
$jieqiSmiles[19] = array('code'=>'/:T', 'url'=>'20.gif', 'emotion'=>'Ż��');
?>