<?php 

$jieqiBlocks[]=array('bid'=>0, 'blockname'=>'��Ա��Ϣ', 'module'=>'system', 'filename'=>'block_uinfo', 'classname'=>'BlockSystemUinfo', 'side'=>0, 'title'=>'��Ա��Ϣ', 'vars'=>'', 'template'=>'', 'contenttype'=>4, 'custom'=>0, 'publish'=>3, 'hasvars'=>1);

$jieqiBlocks[]=array('bid'=>0, 'blockname'=>'��Ա����', 'module'=>'system', 'filename'=>'block_ufriends', 'classname'=>'BlockSystemUfriends', 'side'=>0, 'title'=>'��Ա����', 'vars'=>'', 'template'=>'', 'contenttype'=>4, 'custom'=>0, 'publish'=>3, 'hasvars'=>1);

$jieqiBlocks[]=array('bid'=>0, 'blockname'=>'��Ա����', 'module'=>'system', 'filename'=>'block_ulinks', 'classname'=>'BlockSystemUlinks', 'side'=>0, 'title'=>'��Ա����', 'vars'=>'', 'template'=>'', 'contenttype'=>4, 'custom'=>0, 'publish'=>3, 'hasvars'=>1);

$jieqiBlocks[]=array('bid'=>0, 'blockname'=>'�����Ʒ', 'module'=>'article', 'filename'=>'block_uarticles', 'classname'=>'BlockArticleUarticles', 'side'=>4, 'title'=>'�����Ʒ', 'vars'=>'', 'template'=>'', 'contenttype'=>4, 'custom'=>0, 'publish'=>3, 'hasvars'=>1);

$jieqiBlocks[]=array('bid'=>0, 'blockname'=>'��Ա���', 'module'=>'article', 'filename'=>'block_ubookcase', 'classname'=>'BlockArticleUbookcase', 'side'=>4, 'title'=>'��Ա���', 'vars'=>'', 'template'=>'', 'contenttype'=>4, 'custom'=>0, 'publish'=>3, 'hasvars'=>1);

$jieqiBlocks[]=array('bid'=>0, 'blockname'=>'�� �� ��', 'module'=>'system', 'filename'=>'block_uptopics', 'classname'=>'BlockSystemUptopics', 'side'=>4, 'title'=>'�� �� ��', 'vars'=>'', 'template'=>'', 'contenttype'=>4, 'custom'=>0, 'publish'=>3, 'hasvars'=>1);
?>