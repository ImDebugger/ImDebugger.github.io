<?php
$jieqiCollect['sitename'] = 'һ��';
$jieqiCollect['siteurl'] = 'http://www.17k.com';
$jieqiCollect['subarticleid'] = '';
$jieqiCollect['subchapterid'] = '';
$jieqiCollect['proxy_host'] = '';
$jieqiCollect['proxy_port'] = '';
$jieqiCollect['autoclear'] = '0';
$jieqiCollect['defaultfull'] = '0';
$jieqiCollect['referer'] = '1';
$jieqiCollect['pagecharset'] = 'utf8';
$jieqiCollect['urlarticle'] = 'http://www.17k.com/book/<{articleid}>.html';
$jieqiCollect['articletitle']['left'] = '<h1><a href="/list/$.html" target="_blank">';
$jieqiCollect['articletitle']['right'] = '</a></h1>';
$jieqiCollect['articletitle']['middle'] = '!!!!';
$jieqiCollect['author']['left'] = '<address>���ߣ�<a target="_blank" href="/main/author.do!>';
$jieqiCollect['author']['right'] = '</a>';
$jieqiCollect['author']['middle'] = '!!!!';
$jieqiCollect['sort']['left'] = '<a href="/">��ҳ</a>!&raquo;!<a href="~" target="_blank">';
$jieqiCollect['sort']['right'] = '</a>!&raquo;';
$jieqiCollect['sort']['middle'] = '!!!!';
$jieqiCollect['keyword']['left'] = '<b>��ǩ:</b>';
$jieqiCollect['keyword']['right'] = '</div>!</div>!</div>!<div id="fragment-2" class="content">';
$jieqiCollect['keyword']['middle'] = '****';
$jieqiCollect['intro']['left'] = '<div id="fragment-0" class="content">!<p><a href="/list/$.html" target="_blank">';
$jieqiCollect['intro']['right'] = '</a></p><br/>';
$jieqiCollect['intro']['middle'] = '****';
$jieqiCollect['articleimage']['left'] = '<img alt="~" src="';
$jieqiCollect['articleimage']['right'] = '" width="200" height="282" border="0"/>!</div>!</div>';
$jieqiCollect['articleimage']['middle'] = '~~~~';
$jieqiCollect['filterimage'] = '/images/program/default_cover.gif';
$jieqiCollect['indexlink'] = '';
$jieqiCollect['fullarticle'] = '';
$jieqiCollect['sortid']['�������'] = '1';
$jieqiCollect['sortid']['��������'] = '3';
$jieqiCollect['sortid']['��ʷ����'] = '4';
$jieqiCollect['sortid']['Ů��ʱ��'] = '10';
$jieqiCollect['sortid']['��Ϸ����'] = '6';
$jieqiCollect['sortid']['�ֲ�����'] = '8';
$jieqiCollect['sortid']['�Ļ����'] = '10';
$jieqiCollect['sortid']['������־'] = '10';
$jieqiCollect['sortid']['��������'] = '10';
$jieqiCollect['sortid']['default'] = '10';
$jieqiCollect['urlindex'] = 'http://www.17k.com/list/<{articleid}>.html';
$jieqiCollect['volume']['left'] = '<div class="bookTitle"><b>';
$jieqiCollect['volume']['right'] = '</b><cite><a href="javascript:readvolume($);">���־��Ķ���</a></cite></div>';
$jieqiCollect['volume']['middle'] = '!!!!';
$jieqiCollect['chapter']['left'] = '<li><a title=\'������$,�������ڣ�~\' href="/html/books/~" target="_blank">';
$jieqiCollect['chapter']['right'] = '</a></li>';
$jieqiCollect['chapter']['middle'] = '!!!!';
$jieqiCollect['chapterid']['left'] = '<li><a title=\'������$,�������ڣ�~\' href="/html/books/';
$jieqiCollect['chapterid']['right'] = '.shtml" target="_blank">';
$jieqiCollect['chapterid']['middle'] = '~~~~';
$jieqiCollect['urlchapter'] = 'http://www.17k.com/html/books/<{chapterid}>.shtml';
$jieqiCollect['content']['left'] = '<td colspan="4" scope="col" class="thebc" id="tcc">';
$jieqiCollect['content']['right'] = '</td>!</tr>!</table>';
$jieqiCollect['content']['middle'] = '****';
$jieqiCollect['contentfilter'] = '<script!></script>
<div!>!</div>
<font!>!</font>
<span!>!<span>
<style!>!</style>';
$jieqiCollect['contentreplace'] = '';
$jieqiCollect['collectimage'] = '1';
$jieqiCollect['imagetranslate'] = '0';
$jieqiCollect['addimagewater'] = '0';
$jieqiCollect['imagebgcolor'] = '';
$jieqiCollect['imageareaclean'] = '';
$jieqiCollect['imagecolorclean'] = '';
$jieqiCollect['listcollect']['0']['title'] = '�������';
$jieqiCollect['listcollect']['0']['urlpage'] = 'http://www.17k.com/main/bookStore.do?categoryId=0&orderType=3&isVIP=0&isDone=0&currentPage=<{pageid}>';
$jieqiCollect['listcollect']['0']['articleid']['left'] = '<td align="left"><a target=_blank href=\'/html/bookAbout.htm?bid=';
$jieqiCollect['listcollect']['0']['articleid']['right'] = '\' class="~">';
$jieqiCollect['listcollect']['0']['articleid']['middle'] = '$$$$';
$jieqiCollect['listcollect']['0']['startpageid'] = '1';
$jieqiCollect['listcollect']['0']['nextpageid'] = '++';
$jieqiCollect['listcollect']['0']['maxpagenum'] = '5';

?>