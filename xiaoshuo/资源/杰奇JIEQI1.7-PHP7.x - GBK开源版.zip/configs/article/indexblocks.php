<?php
//�������
$jieqiBlocks[]=array('bid'=>0, 'blockname'=>'�û���¼', 'module'=>'system', 'filename'=>'block_login', 'classname'=>'BlockSystemLogin', 'side'=>0, 'title'=>'�û���¼', 'vars'=>'', 'template'=>'', 'contenttype'=>4, 'custom'=>0, 'publish'=>3, 'hasvars'=>0);

$jieqiBlocks[]=array('bid'=>0, 'blockname'=>'�����Ķ�', 'module'=>'article', 'filename'=>'block_sort', 'classname'=>'BlockArticleSort', 'side'=>JIEQI_SIDEBLOCK_LEFT, 'title'=>'�����Ķ�', 'vars'=>'', 'template'=>'', 'contenttype'=>JIEQI_CONTENT_TXT, 'custom'=>0, 'publish'=>3, 'hasvars'=>0);

$jieqiBlocks[]=array('bid'=>0, 'blockname'=>'�� �� ��', 'module'=>'article', 'filename'=>'block_toplist', 'classname'=>'BlockArticleToplist', 'side'=>JIEQI_SIDEBLOCK_LEFT, 'title'=>'�� �� ��', 'vars'=>'', 'template'=>'', 'contenttype'=>JIEQI_CONTENT_TXT, 'custom'=>0, 'publish'=>3, 'hasvars'=>0);

$jieqiBlocks[]=array('bid'=>0, 'blockname'=>'����������', 'module'=>'article', 'filename'=>'block_articlelist', 'classname'=>'BlockArticleArticlelist', 'side'=>0, 'title'=>'����������', 'vars'=>'allvisit,15,0,0,0,0', 'template'=>'block_allvisit.html', 'contenttype'=>4, 'custom'=>0, 'publish'=>3, 'hasvars'=>1);

$jieqiBlocks[]=array('bid'=>0, 'blockname'=>'����������', 'module'=>'article', 'filename'=>'block_articlelist', 'classname'=>'BlockArticleArticlelist', 'side'=>0, 'title'=>'����������', 'vars'=>'monthvisit,15,0,0,0,0', 'template'=>'block_monthvisit.html', 'contenttype'=>4, 'custom'=>0, 'publish'=>3, 'hasvars'=>1);

//�м�����
$jieqiBlocks[]=array('bid'=>0, 'blockname'=>'�����Ƽ�', 'module'=>'article', 'filename'=>'block_commend', 'classname'=>'BlockArticleCommend', 'side'=>5, 'title'=>'�����Ƽ�', 'vars'=>'1|2|3|4|5|6|7|8', 'template'=>'block_commend.html', 'contenttype'=>1, 'custom'=>0, 'publish'=>3, 'hasvars'=>2);

$jieqiBlocks[]=array('bid'=>0, 'blockname'=>'ԭ������', 'module'=>'article', 'filename'=>'block_articlelist', 'classname'=>'BlockArticleArticlelist', 'side'=>5, 'title'=>'ԭ������', 'vars'=>'lastupdate,15,0,1,0,0', 'template'=>'block_authorupdate.html', 'contenttype'=>4, 'custom'=>0, 'publish'=>3, 'hasvars'=>1);

$jieqiBlocks[]=array('bid'=>0, 'blockname'=>'ת�ظ���', 'module'=>'article', 'filename'=>'block_articlelist', 'classname'=>'BlockArticleArticlelist', 'side'=>5, 'title'=>'ת�ظ���', 'vars'=>'lastupdate,15,0,2,0,0', 'template'=>'block_masterupdate.html', 'contenttype'=>4, 'custom'=>0, 'publish'=>3, 'hasvars'=>1);

//�ұ�����
$jieqiBlocks[]=array('bid'=>0, 'blockname'=>'��������', 'module'=>'article', 'filename'=>'block_search', 'classname'=>'BlockArticleSearch', 'side'=>1, 'title'=>'��������', 'vars'=>'', 'template'=>'', 'contenttype'=>0, 'custom'=>0, 'publish'=>3, 'hasvars'=>0);

$jieqiBlocks[]=array('bid'=>0, 'blockname'=>'���ҹ���', 'module'=>'article', 'filename'=>'block_writerbox', 'classname'=>'BlockArticleWriterbox', 'side'=>1, 'title'=>'���ҹ���', 'vars'=>'', 'template'=>'', 'contenttype'=>0, 'custom'=>0, 'publish'=>2, 'hasvars'=>0);

$jieqiBlocks[]=array('bid'=>0, 'blockname'=>'��վ�Ƽ�', 'module'=>'article', 'filename'=>'block_articlelist', 'classname'=>'BlockArticleArticlelist', 'side'=>1, 'title'=>'��վ�Ƽ�', 'vars'=>'toptime,15,0,0,0,0', 'template'=>'block_toptime.html', 'contenttype'=>4, 'custom'=>0, 'publish'=>3, 'hasvars'=>1);

$jieqiBlocks[]=array('bid'=>0, 'blockname'=>'���Ƽ���', 'module'=>'article', 'filename'=>'block_articlelist', 'classname'=>'BlockArticleArticlelist', 'side'=>1, 'title'=>'���Ƽ���', 'vars'=>'allvote,15,0,0,0,0', 'template'=>'block_allvote.html', 'contenttype'=>4, 'custom'=>0, 'publish'=>3, 'hasvars'=>1);

$jieqiBlocks[]=array('bid'=>0, 'blockname'=>'�����Ƽ�', 'module'=>'article', 'filename'=>'block_articlelist', 'classname'=>'BlockArticleArticlelist', 'side'=>1, 'title'=>'�����Ƽ�', 'vars'=>'monthvote,15,0,0,0,0', 'template'=>'block_monthvote.html', 'contenttype'=>4, 'custom'=>0, 'publish'=>3, 'hasvars'=>1);

?>