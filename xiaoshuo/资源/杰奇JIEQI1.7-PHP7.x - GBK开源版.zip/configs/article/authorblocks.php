<?php 
$jieqiBlocks[0]=array('bid'=>0, 'blockname'=>'������', 'module'=>'article', 'filename'=>'block_writerbox', 'classname'=>'BlockArticleWriterbox', 'side'=>JIEQI_SIDEBLOCK_LEFT, 'title'=>'������', 'vars'=>'', 'template'=>'', 'contenttype'=>JIEQI_CONTENT_TXT, 'custom'=>0, 'publish'=>3, 'hasvars'=>0);

$jieqiBlocks[1]=array('bid'=>0, 'blockname'=>'ԭ������', 'module'=>'article', 'filename'=>'block_myarticles', 'classname'=>'BlockArticleMyarticles', 'side'=>JIEQI_SIDEBLOCK_LEFT, 'title'=>'ԭ������', 'vars'=>'', 'template'=>'', 'contenttype'=>JIEQI_CONTENT_PHP, 'custom'=>0, 'publish'=>3, 'hasvars'=>0);

?>