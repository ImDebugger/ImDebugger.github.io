<?php 
$jieqiBlocks[0]=array('bid'=>0, 'blockname'=>'�����Ķ�', 'module'=>'article', 'filename'=>'block_sort', 'classname'=>'BlockArticleSort', 'side'=>JIEQI_SIDEBLOCK_LEFT, 'title'=>'�����Ķ�', 'vars'=>'', 'template'=>'', 'contenttype'=>JIEQI_CONTENT_TXT, 'custom'=>0, 'publish'=>3, 'hasvars'=>0);

$jieqiBlocks[1]=array('bid'=>0, 'blockname'=>'�� �� ��', 'module'=>'article', 'filename'=>'block_toplist', 'classname'=>'BlockArticleToplist', 'side'=>JIEQI_SIDEBLOCK_LEFT, 'title'=>'�� �� ��', 'vars'=>'', 'template'=>'', 'contenttype'=>JIEQI_CONTENT_TXT, 'custom'=>0, 'publish'=>3, 'hasvars'=>0);

$jieqiBlocks[2]=array('bid'=>0, 'blockname'=>'��������', 'module'=>'article', 'filename'=>'block_search', 'classname'=>'BlockArticleSearch', 'side'=>JIEQI_SIDEBLOCK_LEFT, 'title'=>'��������', 'vars'=>'', 'template'=>'', 'contenttype'=>JIEQI_CONTENT_TXT, 'custom'=>0, 'publish'=>3, 'hasvars'=>0);

?>