<?php
$jieqiRight['article']['maxbookmarks']['caption'] = '�������ղ���';
$jieqiRight['article']['maxbookmarks']['honors']['1'] = '';
$jieqiRight['article']['maxbookmarks']['honors']['2'] = '';
$jieqiRight['article']['maxbookmarks']['honors']['3'] = '';
$jieqiRight['article']['maxbookmarks']['honors']['4'] = '';
$jieqiRight['article']['maxbookmarks']['honors']['5'] = '';
$jieqiRight['article']['maxbookmarks']['honors']['6'] = '';
$jieqiRight['article']['maxbookmarks']['rescription'] = '';
$jieqiRight['article']['dayvotes']['caption'] = 'ÿ�������Ƽ�����';
$jieqiRight['article']['dayvotes']['honors']['1'] = '';
$jieqiRight['article']['dayvotes']['honors']['2'] = '';
$jieqiRight['article']['dayvotes']['honors']['3'] = '';
$jieqiRight['article']['dayvotes']['honors']['4'] = '';
$jieqiRight['article']['dayvotes']['honors']['5'] = '';
$jieqiRight['article']['dayvotes']['honors']['6'] = '';
$jieqiRight['article']['dayvotes']['rescription'] = '';

?>