<?php
$jieqiCollectsite['1']['name'] = '���������';
$jieqiCollectsite['1']['config'] = 'cmfu_com';
$jieqiCollectsite['1']['url'] = 'http://www.cmfu.com';
$jieqiCollectsite['1']['subarticleid'] = '';
$jieqiCollectsite['1']['enable'] = '1';
$jieqiCollectsite['2']['name'] = '�ý�����';
$jieqiCollectsite['2']['config'] = 'hjsm_net';
$jieqiCollectsite['2']['url'] = 'http://hjsm.tom.com';
$jieqiCollectsite['2']['subarticleid'] = '';
$jieqiCollectsite['2']['enable'] = '1';
$jieqiCollectsite['22']['name'] = 'һ��ԭ����ѧ��';
$jieqiCollectsite['22']['config'] = '17k_com';
$jieqiCollectsite['22']['url'] = 'http://www.17k.com';
$jieqiCollectsite['22']['enable'] = '1';
?>