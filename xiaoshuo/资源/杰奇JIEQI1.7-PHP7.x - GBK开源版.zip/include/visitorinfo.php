<?php
class VisitorInfo
{

	/**
	 * ȡ��IP
	 * 
	 * @param      void
	 * @access     public
	 * @return     string
	 */
	function getIp()
	{
		if(isset($_SERVER['HTTP_CLIENT_IP'])) $ip=$_SERVER['HTTP_CLIENT_IP'];
		elseif(isset($_SERVER['HTTP_X_FORWARDED_FOR'])) $ip=$_SERVER['HTTP_X_FORWARDED_FOR'];
		else  $ip=$_SERVER['REMOTE_ADDR'];
		$ip=trim($ip);
		if(!is_numeric(str_replace('.','',$ip))) $ip='0.0.0.0';
		return $ip;
	}

	/**
	 * ȡ��IP���ڵĵ���λ��
	 * 
	 * @param      string      $ip
	 * @access     public
	 * @return     string
	 */
	function getIpLocation ( $ip = '' )
	{
		include_once(JIEQI_ROOT_PATH.'/include/ip2location.php');

		if (empty($ip)) $ip = VisitorInfo::getIp();
		
		if($ip=='0.0.0.0') return 'unknow';

		$wry = new Ip2Location ;

		$wry->qqwry ( $ip );

		$returnVal = $wry->Country.$wry->Local ;
		return $returnVal;
	}

	/**
	 * ȡ�õ�ǰ���ʵ�uri
	 * 
	 * @param      void
	 * @access     public
	 * @return     string
	 */
	function getUrl(){
		$server = substr(getenv('SERVER_SOFTWARE'), 0, 3);

		if($server == 'Apa')
		{
			$wookie = $server;
			$url    = getenv('REQUEST_URI');
		}
		else if($server == 'Mic' || $server == 'Aby')
		{
			$protocol = (getenv('HTTPS') == 'off') ? ('http://') : ('https://');
			$query    = (getenv('QUERY_STRING'))   ? ('?'.getenv('QUERY_STRING')) : ('');
			$url      = $protocol.getenv('SERVER_NAME').getenv('SCRIPT_NAME').$query;
		}
		else if($server == 'Aby')
		{
			$protocol = (getenv('HTTPS') == 'on') ? ('https://') : ('http://');
			$query    = (getenv('QUERY_STRING'))  ? ('?'.getenv('QUERY_STRING')) : ('');
			$url      = $protocol.getenv('SERVER_NAME').getenv('SCRIPT_NAME').$query;
		}
		else
		{
			$url = getenv('REQUEST_URI');
		}

		return $url;
	}

	/**
	 * ȡ�����������
	 * 
	 * @param      void
	 * @access     public
	 * @return     string
	 */
	function getBrowser()
	{
		global $_SERVER;
		$Agent = $_SERVER['HTTP_USER_AGENT'];
		$browser = $browserver = '';
		$Browsers = array('Lynx', 'MOSAIC', 'AOL', 'Opera', 'JAVA', 'MacWeb', 'WebExplorer', 'OmniWeb');
		for($i = 0; $i <= 7; $i ++){
			if(strpos($Agent, $Browsers[$i])){
				$browser = $Browsers[$i];
			}
		}
		if(preg_match('Mozilla', $Agent))
		{

			if(preg_match('MSIE', $Agent)){
				preg_match('/MSIE (.*);/U',$Agent,$args);
				$browserver = $args[1];
				$browser = 'Internet Explorer';
			}
			else if(preg_match('Opera', $Agent)) {
				$temp = explode(')', $Agent);
				$browserver = $temp[1];
				$temp = explode(' ', $browserver);
				$browserver = $temp[2];
				$browser = 'Opera';
			}
			else {
				$temp = explode('/', $Agent);
				$browserver = $temp[1];
				$temp = explode(' ', $browserver);
				$browserver = $temp[0];
				$browser = 'Netscape Navigator';
			}
		}
		//$browserver = preg_replace('/([d.]+)/','\1',$browserver);
		if($browser != ''){
			$browseinfo = $browser.' '.$browserver;
		} else {
			$browseinfo = false;
		}
		return $browseinfo;
	}

	/**
	 * ȡ�ò���ϵͳ����
	 * 
	 * @param      void
	 * @access     public
	 * @return     string
	 */
	function getOS ()
	{
		global $_SERVER;
		$agent = $_SERVER['HTTP_USER_AGENT'];
		$os = false;
		if (preg_match('win', $agent) && strpos($agent, '95')){
			$os = 'Windows 95';
		}
		else if (preg_match('win 9x', $agent) && strpos($agent, '4.90')){
			$os = 'Windows ME';
		}
		else if (preg_match('win', $agent) && preg_match('98', $agent)){
			$os = 'Windows 98';
		}
		else if (preg_match('win', $agent) && preg_match('nt 5.1', $agent)){
			$os = 'Windows XP';
		}
		else if (preg_match('win', $agent) && preg_match('nt 5', $agent)){
			$os = 'Windows 2000';
		}
		else if (preg_match('win', $agent) && preg_match('nt', $agent)){
			$os = 'Windows NT';
		}
		else if (preg_match('win', $agent) && preg_match('32', $agent)){
			$os = 'Windows 32';
		}
		else if (preg_match('linux', $agent)){
			$os = 'Linux';
		}
		else if (preg_match('unix', $agent)){
			$os = 'Unix';
		}
		else if (preg_match('sun', $agent) && preg_match('os', $agent)){
			$os = 'SunOS';
		}
		else if (preg_match('ibm', $agent) && preg_match('os', $agent)){
			$os = 'IBM OS/2';
		}
		else if (preg_match('Mac', $agent) && preg_match('PC', $agent)){
			$os = 'Macintosh';
		}
		else if (preg_match('PowerPC', $agent)){
			$os = 'PowerPC';
		}
		else if (preg_match('AIX', $agent)){
			$os = 'AIX';
		}
		else if (preg_match('HPUX', $agent)){
			$os = 'HPUX';
		}
		else if (preg_match('NetBSD', $agent)){
			$os = 'NetBSD';
		}
		else if (preg_match('BSD', $agent)){
			$os = 'BSD';
		}
		else if (preg_match('OSF1', $agent)){
			$os = 'OSF1';
		}
		else if (preg_match('IRIX', $agent)){
			$os = 'IRIX';
		}
		else if (preg_match('FreeBSD', $agent)){
			$os = 'FreeBSD';
		}
		else if (preg_match('teleport', $agent)){
			$os = 'teleport';
		}
		else if (preg_match('flashget', $agent)){
			$os = 'flashget';
		}
		else if (preg_match('webzip', $agent)){
			$os = 'webzip';
		}
		else if (preg_match('offline', $agent)){
			$os = 'offline';
		}
		else {
			$os = 'Unknown';
		}
		return $os;
	}

	/**
	 * ȡ�����ӵ��˵�ҳ�ĵ�ַ����һҳ��
	 * 
	 * @param      void
	 * @access     public
	 * @return     string
	 */
	function getFromUrl()
	{
		if (!empty($_REQUEST['fromurl']))$fromUrl = $_REQUEST['fromurl'] ;
		else if ($_SERVER['HTTP_REFERER']!="")$fromUrl = $_SERVER['HTTP_REFERER'] ;
		else $fromUrl = $_SERVER['REQUEST_URI'];
		return $fromUrl ;
	}

}

?>