/*
 *basic functions
 */
define(['domReady', 'JC.common', 'JC.Panel', 'JC.Valid', 'zlang.dialog.login', 'zlang.tool'], 
    function( doc, jc, Pannel, Valid, DialogLogin) {
    var util = {};
    util.ui = {};
    util.bs = {};
    util.io = {};
    util.url = {};
    util.package = {};
    util.status = {
        postLinkInited: false,
        isTest: document.location.protocol == 'file:'
    };

    window.isTest = window.isTest || util.status.isTest;


    util.io.getErrorMsg = function(data) {
        var data = data,
			errorno = data.code,		
			errorMsg = '' ;
		
		if(data.msg){
			errorMsg = data.msg
			}else{
			errorMsg = (errorno == 0) ? '操作成功！' : '操作失败~'	
			}
        return errorMsg;
    };

    util.ui = {
        showFail: function(err, ele, callback) {

            var msg = err,
                ele = ele && $(ele);

            JC.msgbox(msg, ele, 1, callback);
        },
        showSucc: function(msg, ele, callback) {

            var msg = msg || '操作成功!',
                ele = ele && $(ele);
            JC.msgbox(msg, ele, 0, callback);
        },
        clearPopup: function() {
            // UXC.hideAllPopup(true);
        }
    };

    util.package.textareaCounter = function() {
        var textarea = $('textarea[data-counter]');
        if (!textarea.length) return;
        var t;

        textarea.each(function(i) {
            $(this).on('focus', function() {

                t && clearInterval(t);
                t = null;
                /*
                 *使用 data-maxlength 防止浏览器默认阻止超过字数时的继续输入
                 */
                var txt = $(this),
                    ctr = txt.data('counter'),
                    lmt = txt.attr('maxlength') || ~~txt.data('maxlength');

                if (ctr.indexOf('|') > 0) {
                    var sel = ctr.split('|'),
                        ctx = sel[0],
                        tar = sel[1];
                    ctr = txt.closest(ctx).find(tar)
                } else {
                    ctr = $(ctr)
                }

                var form = txt.closest('form');
                if (form.length) {
                    form.on('reset', function() {
                        txt.focus()
                    })
                };

                t = setInterval(function() {
                    var val = $.trim(txt.val()),
                        len = val.length;
                    if (len > lmt) {
                        ctr.html('<em><strong>' + len + '</strong></em>/' + lmt);
                        txt.addClass('pub-disable');
                    } else {
                        ctr.html('<em>' + len + '</em>/' + lmt);
                        txt.removeClass('pub-disable');
                    }

                }, 1e2);
            }).on('blur', function() {
                t && clearInterval(t);
            });
        });

    };

    /*
     *标记当前元素
     */
    util.ui.cur = function(ele, cls, tag) {
        var ele = $(ele) || ele;
        var tag = tag || "";
        var mark = cls || "cur";
        ele.addClass(mark).siblings(tag).removeClass(mark);
    };

    /*
     *TAB 切换
     */

    util.ui.tab = function(id_tab, tag_tab, id_con, tag_con, act) {
        var act = act || 'click',
            tabHdl = $(id_tab).find(tag_tab),
            tabCon = $(id_con).find(tag_con),
            arr = tabHdl.toArray();

        tabHdl.on(act, function(e) {

            var btn = $(this),
                idx = btn.index(),
                box = tabCon.eq(idx),
                cur = util.ui.cur;

            cur(this, "cur");

            box.show().siblings(tag_con).hide();
            btn.blur();
            e.preventDefault();
        });
    };

    util.url.refresh = function(t) {
        var href = window.location.href,
            time = parseInt(t) ? t * 1e3 : 0;
        setTimeout(function() {
            window.location = JC.f.addUrlParams(href, {
                __t: new Date() * 1
            })
        }, time);
    };

    /*
     *JSON 数据解析
     */
    util.io.parseJson = function(data) {
        try {
            if (typeof data == 'object') {
                return data;
            };
            if (typeof data == 'string') {
                return JSON.parse(data);
            };
        } catch (e) {
            console.log('parseJson error \n org-data: \n ' + data)
        }

    };

    /*获取模板代码*/
    util.io.getTmp = function(id) {
        return JC.f.scriptContent('#' + id);
        return $('#' + id).html().replace(/\/n/g, '');
    };

    /*
     *JSON 数据处理
     */

    util.io.handleJson = function(data, callback) {
        var data = util.io.parseJson(data);
        if (callback && typeof callback == 'function') {
            callback(data);
        }
    };

    /*
     *判断AJAX返回的结果是否成功
     */
    util.io.ajaxRes = function(data) {
        var data = util.io.parseJson(data);
        if (data.errorno != 0) {
            return util.io.getErrorMsg(data.errorno);
        } else {
            return 'ok';
        };
    };


    /*优雅的移除元素*/
    util.ui.fadeRemove = function(ele, time) {
        $(ele).fadeOut(time || 6e2, function() {
            setTimeout(function() {
                $(ele).remove()
            })
        })
    };

    /*禁用，启用元素*/
    util.ui.dis = function(ele) {
        // var disCls = 'disabled';
        // if (!ele) return;
        // ele.each(function(i) {
        //     $(this).attr(disCls, disCls).addClass(disCls);
        // })

    };

    util.ui.ena = function(ele) {
        // var disCls = 'disabled';
        // if (!ele) return;
        // ele.each(function(i) {
        //     $(this).removeClass(disCls).removeAttr(disCls);
        // })
    };

    // 有点地方还会有，重改一下名字
    util.ui.ena2 = function(ele) {
        var disCls = 'disabled';
        if (!ele) return;
        ele.each(function(i) {
            $(this).removeClass(disCls).removeAttr(disCls);
        })
    };
     util.ui.dis2 = function(ele) {
        var disCls = 'disabled';
        if (!ele) return;
        ele.each(function(i) {
            $(this).attr(disCls, disCls).addClass(disCls);
        })
    };
    /*操作成功之后提示并且刷新当前网页*/
    util.ui.doneRefresh = function(btn, time) {
        util.ui.showSucc(null, btn);
        util.url.refresh(time);
    };

    /*操作成功之后提示并且重定向到地址*/
    util.ui.doneRedirect = function(btn, url) {
        util.ui.showSucc(null, btn);
        setTimeout(function() {
            window.location = url
        }, 2e3);
    };

    util.io.xssEscape = function(s) {
        s = String(s === null ? "" : s);
        return s.replace(/&(?!\w+;)|["'<>\\]/g, function(s) {
            switch (s) {
                case "&":
                    return "&amp;";
                case "\\":
                    return "\\\\";
                case '"':
                    return '&quot;';
                case "'":
                    return '&#39;';
                case "<":
                    return "&lt;";
                case ">":
                    return "&gt;";
                default:
                    return s;
            }
        });
    };


    $(function() {
        $('[data-role="tab"]').each(function() {
            var tabCon = $(this),
                tabTag = tabCon.data('tag'),
                con = tabCon.data('con'),
                conTag = $(con).data('tag'),
                act = tabCon.data('act') || 'click';

            //console.log(tabCon);
            //console.log(tabCon,tabTag,con,conTag,act);

            util.ui.tab(tabCon, tabTag, con, conTag, act);
            $(tabTag).filter('.cur').trigger(act);

        });

        util.ui.tab('.smp-tab', 'li', '.smp-con', 'table');

        var txtCtr = $('textarea[data-counter]');
        if (txtCtr.length) {
            util.package.textareaCounter()
        };
    });



    util.package.postLinkCtl = function() {
        if (util.status.postLinkInited) {
            return;
        }

        var btnCls = '.js-post-link',
            doc = document;

        $(doc).delegate(btnCls, 'click', function(e) {
            var btn = $(this),
                needCfm = btn.data('cfmmsg'),
                cfmType = btn.text().indexOf('删除') >= 0 ? 1 : 2;

            if (needCfm) {
                var cfmTips = btn.data('cfmmsg') ? btn.data('cfmmsg') : '确实要' + btn.text() + '么？';
                JC.confirm(cfmTips, this, cfmType).on('confirm', function() {
                    ajaxPost(btn)
                });
            } else {
                ajaxPost(btn)
            }
        });

        function onPostSuccess(btn) {


            var cb = util.url.refresh,
                doneurl = btn.data('doneurl') || null,
                donefn = btn.data('done') || null,
                callbacks = {
                    'refresh': util.url.refresh,
                    'go-1': function() {
                        window.history.go(-1)
                    },
                    'rmtr': function() {
                        var tr = btn.parents('tr');
                        tr.fadeOut(600, function() {
                            tr.remove()
                        });
                    },
                    'rmli': function() {
                        var li = btn.parents('li');
                        li.fadeOut(600, function() {
                            li.remove()
                        });
                    }
                };

            if (doneurl) {
                cb = function() {
                    window.location = doneurl;
                }
            } else if (donefn) {
                cb = callbacks[donefn];
            };

            util.ui.showSucc(null, btn, cb);
            setTimeout(cb, 2e3);
        };

        function ajaxPost(btn) {

            var suber = btn,
                api = suber.data('api') || window.location.href.split('#')[0],
                postData = suber.data('post');
            // suber.attr('disabled', true).addClass('disabled');

            // $.ajax({
            //         type: "POST",
            //         url: api,
            //         contentType: 'text/plain',
            //         data: postData,
            //         dataType: 'json'
            //     })
            Zlib.tool.ajax(api, "POST", postData).done(function(data) {
                    var data = util.io.parseJson(data);
                    if (data.code <= 0) {
                       util.ui.onAjaxRetFail(data, suber)
                    } else {
                        onPostSuccess(btn);
                    };
                })
                .fail(function() {
                    util.ui.showFail('操作失败，请稍后重试');
                    util.ui.ena(suber)
                });
        };

        util.status.postLinkInited = true;

    };
	

    util.package.formValidCtl = function() {
        var doc = document;

        $(doc).on('focus', 'form[ignoreAutoCheckEvent] input,form[ignoreAutoCheckEvent] select,form[ignoreAutoCheckEvent] textarea ', function(e) {
            Valid.clearError($(this))
        })


        $(doc).on('submit', '.valid-form', function(e) {
            return Valid($(this))
        })
    };

    util.package.ajaxFormCtl = function() {
        var doc = document;
        $(doc).on('submit', '.ajax-form', function(e) {
            e.preventDefault();

            var form = $(this);

            if (form.hasClass('valid-form')) {
                if (!Valid(form)) return;
            }

            var api = form.attr('action') || window.location.href.split('#')[0],
                postData = form.serialize(),
                sendType = form.attr('method') || 'POST',
                suber = form.find(':submit'),
                loading = false,
                dialog = null;
            util.ui.dis(suber);

            // $.ajax({ 
            //         url: api,
            //         data: postData,
            //         contentType: 'text/plain',
            //         type: sendType,
            //         dataType: 'json'
            //     })
            Zlib.tool.ajax(api, sendType, postData).done(function(data) {
                    var data = util.io.parseJson(data);
                    if (data.code <= 0) {
                        // fail
                        if (data.code == -400) {
                            DialogLogin.show();
                        } else {
                            util.ui.onAjaxRetFail(data, suber)
                        }

                        // var cont = form.find('textarea').val();
                        var cont = form.find('textarea').length && form.find('textarea').val();
                        
                        if (cont && (cont.length > 0)) {
                            if (cont.indexOf('@') === 0 || cont.indexOf('@')) {
                            form.find('textarea').val(cont);
                            } else {
                                form.find('textarea').val('');
                            }
                        }
                        
                        // 不取消的input
                        form.find('input[class!="noClear"]').val('');
                    } else {
                        // success
                        util.ui.onAjaxRetSucc(data, suber)
                        form.find('input').val('');
                        form.find('textarea').val('');
                        location.reload(0);
                    };
                })
                .fail(function() {
                    util.ui.showFail('操作失败，请稍后重试');
                    util.ui.ena(suber);
                });

            return false;
        });
    };
	
	util.ui.onAjaxRetSucc = function(data, suber){
		
		var errmsg = util.io.getErrorMsg(data);	
		
		
		 if (data.data && data.data.tmp) {
                 JC.hideAllPanel();
				JC.Dialog(data.data.tmp);
                
				suber && util.ui.ena(suber);
            } else if (errmsg) {
                util.ui.showSucc(errmsg, suber, function() {
                  suber &&  util.ui.ena(suber);
                });
            }
		};
		
	util.ui.onAjaxRetFail = function(data, suber){
		
		var errmsg = util.io.getErrorMsg(data);
		//alert(errmsg);	
		
		 if (data.data && data.data.tmp) {
                JC.hideAllPanel();
				JC.Dialog(data.data.tmp);
                
				suber && util.ui.ena(suber);
            } else if (errmsg) {
                util.ui.showFail(errmsg, suber, function() {
                  suber &&  util.ui.ena(suber);
                });
            }
		};
		
	util.ui.onAjaxResult = function(data, suber){
		//var data = util.io.parseJson(data);	
		
			if (data.errorno != 0) {				
				util.ui.onAjaxRetFail(data, suber)
			} else {
			   util.ui.onAjaxRetSucc(data, suber)
			};
		};	


    util.package.txtlabCtl = function() {
        //return;
        var txtlab = '.txtlab',
            doc = document,
            clsPrefix = 'js-lab-',
            onCls = 'lab-on';

        $(txtlab).each(function() {
            var lab = $(this),
                ipt = lab.find('input'),
                chk = ipt.prop('checked');

            if (chk) {
                lab.addClass(onCls)
            }

        });


        $(doc).on('click', txtlab, function() {

            var lab = $(this),
                ipt = lab.find('input'),
                isRadio = ipt.attr('type') == 'radio',
                name = ipt.attr('name'),
                dis = ipt.attr('disabled') || ipt.attr('readonly');
            //console.log(dis);

            if (dis) return;

            if (isRadio) {
                lab.addClass(onCls);
                ipt.prop('checked', true);
                lab.siblings('label.txtlab').removeClass(onCls);
            } else {
                lab.toggleClass(onCls);
                ipt.prop('checked', lab.hasClass(onCls));
            }

            //lab.addClass(onCls);
            //isRadio && lab.siblings('label.txtlab').removeClass(onCls);	
            //console.log(isRadio);
            return false;
        });

    };




    $(function() {
      
        util.package.postLinkCtl();
        util.package.formValidCtl();
        util.package.ajaxFormCtl();
        util.package.txtlabCtl();
		
		App.ui = $.extend(App.ui,util.ui);

    });



    return util;

});
