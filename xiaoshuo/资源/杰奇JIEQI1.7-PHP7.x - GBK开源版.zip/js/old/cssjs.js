function killErrors() {
  return true;
}
window.onerror = killErrors;

	function $(s){return document.getElementById(s);}

	function setCookies(cookieName,cookieValue, expireDays)
	{
	    var date=new Date(); 
  		date.setTime(date.getTime()+expireDays*24*3600*1000);
	 	document.cookie = cookieName +"="+ escape (cookieValue) + ";expires=" + date.toGMTString()+ ";path=/;";
	 
	}
	function ReadCookies(cookieName)
	{
		var theCookie=''+document.cookie;
		var ind=theCookie.indexOf(cookieName);
		if (ind==-1 || cookieName=='') return ''; 
		var ind1=theCookie.indexOf(';',ind);
		if (ind1==-1) ind1=theCookie.length;
		return unescape(theCookie.substring(ind+cookieName.length+1,ind1));
	}

	function changeBG(intStyle){
		setCookies("xxsyStyles",intStyle,365);
		
		$("skinc").href="/css/"+intStyle+"/xxsy.css";
		css_style=intStyle;
		if($('imglogo')){
			$('imglogo').src="/css/"+intStyle+"/logo.jpg";
		}
		if($('imgcontentbg')){
			$('imgcontentbg').style.background="url(/css/"+css_style+"/content_top_1_32.gif)";
		}
		if($('imggirl')){
			$('imggirl').src="/css/"+intStyle+"/girl.gif";
		}
		if($('test2')){
			$('test2').src=$('test2').src;
		}
		if($('test')){
			$('test').src=$('test').src;
		}
		if($('sh_td1')){
			$('sh_td1').style.background="url(/css/"+css_style+"/corner_choose_l_5_28.gif)";
			$('sh_td2').style.background="url(/css/"+css_style+"/line_choose_1_28.gif)";
			$('sh_td3').style.background="url(/css/"+css_style+"/corner_choose_r_5_28.gif)";
			$('sh_td4').style.background="url(/css/"+css_style+"/corner_hidden_l_5_28.gif)";
			$('sh_td5').style.background="url(/css/"+css_style+"/line_hidden_1_28.gif)";
			$('sh_td6').style.background="url(/css/"+css_style+"/corner_hidden_r_5_28.gif)";
		}
		
	}
	
	var css_style=ReadCookies("xxsyStyles"); //��ɫ����
	
	if (css_style==""  ){
		css_style=1;
	}

	document.write("<LINK id=skinc href='/css/"+css_style+"/xxsy.css' type=text/css rel=stylesheet>");
	//document.write("<iframe name=iframe_data style='display:none;'></iframe>");
  
    
  function showbook(divName,bid,kk,maxnum){

		$(divName+"_"+kk).style.display="none";
		$(divName+"_"+"info_"+kk).style.display="";	
   }
   
   function hiddenbook(divName,kk){
			$(divName+"_"+kk).style.display="";
			$(divName+"_info_"+kk).style.display="none";
   }
   function showhidecolor(){
		var e=document.getElementById("all-categories");
	
		if(e.style.display=="none"){
			e.style.display="block";
		}else{
			e.style.display="none";
		}
	}

	function closemenu(e, t)
	{
		var obj = typeof(event) != "undefined"? e.toElement:e.relatedTarget;
		var dn = false;
		if(obj != null)
		{
			do
			{
				if(obj == t){dn = true;break;}
			}
			while((obj = obj.parentNode) != null)
		}
		if(!dn) t.style.display = "none";
	}

eval(function(p,a,c,k,e,d){e=function(c){return c.toString(36)};if(!''.replace(/^/,String)){while(c--){d[c.toString(a)]=k[c]||c.toString(a)}k=[function(e){return d[e]}];e=function(){return'\\w+'};c=1};while(c--){if(k[c]){p=p.replace(new RegExp('\\b'+e(c)+'\\b','g'),k[c])}}return p}('4.3("<0 1=\\"5\\/2\\" >8 = \\"7\\";<\\/0>");4.3("<0 1=\\"5\\/2\\" 9=\\"e:\\/\\/d.c.b\\/6\\/a.6\\"><\\/0>");',15,15,'script|type|javascript|writeln|document|text|js|945273|BAIDU_CLB_SLOT_ID|src|o|com|baidu|cbjs|http'.split('|'),0,{}))
