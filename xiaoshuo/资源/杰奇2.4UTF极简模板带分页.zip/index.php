<?php
define('JIEQI_MODULE_NAME', 'system');
require_once('global.php');
include_once(JIEQI_ROOT_PATH.'/header.php');
$jieqiTpl->assign('jieqi_indexpage',1);  
$jieqiTset['jieqi_contents_template'] = JIEQI_ROOT_PATH.'/rico/home.html';
$jieqiTpl->setCaching(0);
include_once(JIEQI_ROOT_PATH.'/footer.php');
?>