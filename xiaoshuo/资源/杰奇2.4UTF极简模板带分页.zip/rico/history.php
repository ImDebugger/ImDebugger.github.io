<?php
define('JIEQI_MODULE_NAME', 'system'); 
require_once  $_SERVER['DOCUMENT_ROOT'] .'/global.php';
include_once(JIEQI_ROOT_PATH.'/header.php');
$jieqiTset['jieqi_page_template']=JIEQI_ROOT_PATH.'/rico/history.html'; 
include_once(JIEQI_ROOT_PATH.'/footer.php');  